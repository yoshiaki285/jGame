<?php $dice = rand(1,6); ?>
