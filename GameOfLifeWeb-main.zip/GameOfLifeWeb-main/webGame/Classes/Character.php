<?php
    class Character{
        public $name;
        public $gender;
        public $money;
        public $current;
        public $partner;
        public $age;
    }
?>