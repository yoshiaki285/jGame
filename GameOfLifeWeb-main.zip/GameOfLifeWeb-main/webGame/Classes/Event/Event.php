<?php
interface Event{
    public function event($character);
    public function getName();
    public function getInfo();
}



?>